import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Filter, Briefcase, TrendingUp, Star, BookmarkPlus } from 'lucide-react';
import { useCareerStore, CareerPath } from '../../store/careerStore';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Card, { CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '../../components/ui/Card';

const categories = [
  'All',
  'Computer Science',
  'Data Science',
  'Design',
  'Business',
  'Healthcare',
  'Engineering',
  'Education'
];

const CareerExplorer = () => {
  const { careers, savedCareers, fetchCareers, saveCareer, unsaveCareer, loading } = useCareerStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  
  useEffect(() => {
    fetchCareers();
  }, [fetchCareers]);
  
  const filteredCareers = careers.filter(career => {
    const matchesSearch = career.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          career.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || career.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  const handleToggleSave = (careerId: string) => {
    if (savedCareers.includes(careerId)) {
      unsaveCareer(careerId);
    } else {
      saveCareer(careerId);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <motion.div 
        className="mb-10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Explore Career Paths
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300">
          Discover and explore detailed roadmaps for various career paths
        </p>
      </motion.div>
      
      {/* Search and filters */}
      <div className="mb-10 bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-4">
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <Input
              type="text"
              placeholder="Search for careers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex-shrink-0">
            <div className="relative">
              <label htmlFor="category" className="sr-only">Category</label>
              <div className="flex items-center rounded-lg border border-gray-300 dark:border-gray-700">
                <div className="px-3 py-2 bg-gray-100 dark:bg-gray-700 border-r border-gray-300 dark:border-gray-600 rounded-l-lg">
                  <Filter className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                </div>
                <select
                  id="category"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="p-2 bg-transparent text-gray-700 dark:text-gray-300 pr-8 rounded-r-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400"
                >
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Career cards */}
      {loading ? (
        <div className="text-center py-20">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-300">Loading careers...</p>
        </div>
      ) : filteredCareers.length === 0 ? (
        <div className="text-center py-20 bg-white dark:bg-gray-800 rounded-xl shadow-sm">
          <Briefcase className="h-16 w-16 mx-auto text-gray-300 dark:text-gray-600 mb-4" />
          <h3 className="text-xl font-medium text-gray-900 dark:text-white mb-2">No careers found</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">
            Try adjusting your search or filter to find what you're looking for.
          </p>
          <Button onClick={() => { setSearchTerm(''); setSelectedCategory('All'); }}>
            Clear Filters
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCareers.map((career, index) => (
            <CareerCard 
              key={career.id} 
              career={career} 
              isSaved={savedCareers.includes(career.id)} 
              onToggleSave={handleToggleSave}
              index={index}
            />
          ))}
        </div>
      )}
    </div>
  );
};

interface CareerCardProps {
  career: CareerPath;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
  index: number;
}

const CareerCard = ({ career, isSaved, onToggleSave, index }: CareerCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
    >
      <Card className="h-full flex flex-col">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="mb-2">{career.title}</CardTitle>
              <span className="inline-block bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 text-xs px-2 py-1 rounded">
                {career.category}
              </span>
            </div>
            <button
              onClick={(e) => {
                e.preventDefault();
                onToggleSave(career.id);
              }}
              className={`p-2 rounded-full ${
                isSaved 
                  ? 'text-yellow-500 bg-yellow-50 dark:bg-yellow-900/20' 
                  : 'text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 bg-gray-100 dark:bg-gray-800'
              }`}
              aria-label={isSaved ? 'Unsave career' : 'Save career'}
            >
              {isSaved ? <Star size={20} /> : <BookmarkPlus size={20} />}
            </button>
          </div>
        </CardHeader>
        <CardContent className="flex-grow">
          <CardDescription className="mb-4 line-clamp-3">
            {career.description}
          </CardDescription>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white text-sm mb-2">Key Skills</h4>
              <div className="flex flex-wrap gap-2">
                {career.skills.slice(0, 4).map((skill) => (
                  <span 
                    key={skill} 
                    className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded text-xs"
                  >
                    {skill}
                  </span>
                ))}
                {career.skills.length > 4 && (
                  <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded text-xs">
                    +{career.skills.length - 4}
                  </span>
                )}
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center text-sm">
                <Briefcase size={16} className="mr-1 text-gray-500 dark:text-gray-400" />
                <span className="text-gray-600 dark:text-gray-300">{career.salary.entry}</span>
              </div>
              <div className="flex items-center text-sm text-green-600 dark:text-green-400">
                <TrendingUp size={16} className="mr-1" />
                <span>{career.growth}</span>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Link to={`/careers/${career.id}`} className="w-full">
            <Button className="w-full">View Career Path</Button>
          </Link>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default CareerExplorer;