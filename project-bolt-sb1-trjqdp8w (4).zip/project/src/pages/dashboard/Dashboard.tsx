import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Star, Clock, BarChart } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useCareerStore, CareerPath } from '../../store/careerStore';
import Card, { CardContent, CardFooter, CardHeader, CardTitle } from '../../components/ui/Card';
import Button from '../../components/ui/Button';

const Dashboard = () => {
  const { user } = useAuthStore();
  const { careers, savedCareers, fetchCareers } = useCareerStore();
  
  useEffect(() => {
    fetchCareers();
  }, [fetchCareers]);
  
  const savedCareerDetails = careers.filter(career => savedCareers.includes(career.id));
  
  // Recommended careers (simple implementation for demo)
  const recommendedCareers = careers.filter(career => !savedCareers.includes(career.id)).slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Welcome header */}
      <div className="mb-12">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
          Welcome back, {user?.name || 'User'}!
        </h1>
        <p className="text-gray-600 dark:text-gray-300 text-lg">
          Track your progress, explore recommended career paths, and continue your journey to success.
        </p>
      </div>
      
      {/* Dashboard grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main content - 2/3 width */}
        <div className="lg:col-span-2 space-y-8">
          {/* Progress section */}
          <motion.section 
            className="bg-gradient-to-br from-indigo-600 to-purple-700 text-white rounded-xl p-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-2xl font-bold mb-4">Your Career Journey</h2>
                <p className="text-indigo-100 mb-6">
                  Continue exploring career paths that match your skills and interests.
                </p>
                <Link to="/careers">
                  <Button 
                    variant="outline" 
                    className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                  >
                    Explore All Careers
                    <ArrowRight size={16} className="ml-2" />
                  </Button>
                </Link>
              </div>
              <div className="hidden md:block w-24 h-24 bg-white/10 rounded-full p-4">
                <div className="w-full h-full rounded-full border-4 border-white flex items-center justify-center">
                  <span className="text-2xl font-bold">28%</span>
                </div>
              </div>
            </div>
          </motion.section>
          
          {/* Recommended careers */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                Recommended for You
              </h2>
              <Link to="/careers" className="text-indigo-600 dark:text-indigo-400 font-medium flex items-center">
                View all
                <ArrowRight size={16} className="ml-1" />
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-6">
              {recommendedCareers.map((career, index) => (
                <RecommendedCareerCard key={career.id} career={career} index={index} />
              ))}
            </div>
          </section>
        </div>
        
        {/* Sidebar - 1/3 width */}
        <div className="space-y-8">
          {/* Saved careers */}
          <section>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Saved Careers
            </h2>
            
            {savedCareerDetails.length > 0 ? (
              <div className="space-y-4">
                {savedCareerDetails.map((career) => (
                  <SavedCareerCard key={career.id} career={career} />
                ))}
              </div>
            ) : (
              <Card className="p-6 text-center">
                <div className="flex flex-col items-center">
                  <Star className="h-10 w-10 text-gray-300 dark:text-gray-600 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No saved careers yet</h3>
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    Save careers you're interested in to access them quickly.
                  </p>
                  <Link to="/careers">
                    <Button variant="outline" size="sm">Explore Careers</Button>
                  </Link>
                </div>
              </Card>
            )}
          </section>
          
          {/* Quick links */}
          <section className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
              Quick Links
            </h2>
            
            <ul className="space-y-3">
              <li>
                <Link to="/profile" className="flex items-center text-gray-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400">
                  <div className="bg-indigo-100 dark:bg-indigo-900/30 p-2 rounded-lg mr-3">
                    <BookOpen size={18} className="text-indigo-600 dark:text-indigo-400" />
                  </div>
                  Update Your Profile
                </Link>
              </li>
              <li>
                <Link to="/careers" className="flex items-center text-gray-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400">
                  <div className="bg-sky-100 dark:bg-sky-900/30 p-2 rounded-lg mr-3">
                    <Clock size={18} className="text-sky-600 dark:text-sky-400" />
                  </div>
                  Explore Career Paths
                </Link>
              </li>
              <li>
                <Link to="/resources" className="flex items-center text-gray-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400">
                  <div className="bg-purple-100 dark:bg-purple-900/30 p-2 rounded-lg mr-3">
                    <BarChart size={18} className="text-purple-600 dark:text-purple-400" />
                  </div>
                  Learning Resources
                </Link>
              </li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
};

interface RecommendedCareerCardProps {
  career: CareerPath;
  index: number;
}

const RecommendedCareerCard = ({ career, index }: RecommendedCareerCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card>
        <CardHeader>
          <CardTitle>{career.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-2">
            {career.description}
          </p>
          <div className="flex flex-wrap gap-2 mb-4">
            {career.skills.slice(0, 3).map((skill) => (
              <span 
                key={skill} 
                className="px-2 py-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 rounded text-xs font-medium"
              >
                {skill}
              </span>
            ))}
            {career.skills.length > 3 && (
              <span className="px-2 py-1 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded text-xs font-medium">
                +{career.skills.length - 3} more
              </span>
            )}
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500 dark:text-gray-400">
              Entry: {career.salary.entry}
            </span>
            <span className="text-green-600 dark:text-green-400 font-medium">
              {career.growth}
            </span>
          </div>
        </CardContent>
        <CardFooter>
          <Link to={`/careers/${career.id}`} className="w-full">
            <Button variant="outline" className="w-full">
              View Details
            </Button>
          </Link>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

interface SavedCareerCardProps {
  career: CareerPath;
}

const SavedCareerCard = ({ career }: SavedCareerCardProps) => {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <div className="p-4">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
          {career.title}
        </h3>
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-3">
          <span className="mr-3">{career.category}</span>
          <span className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 px-2 py-0.5 rounded text-xs">
            {career.growth}
          </span>
        </div>
        <Link to={`/careers/${career.id}`}>
          <Button variant="outline" size="sm" className="w-full">
            Continue Learning
          </Button>
        </Link>
      </div>
    </Card>
  );
};

export default Dashboard;